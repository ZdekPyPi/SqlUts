#TEST FILE
from dotenv import load_dotenv
import sys
import os
sys.path.append("./sqlUts")
from sqlUts import *
load_dotenv()
